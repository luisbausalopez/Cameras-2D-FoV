# Changelog

## v0.3.0 (not yet released)

- ol2: move scale line control too when sidebar opens/closes


## v0.2.1 (not yet released)

- ol2, ol3: fixed sidebar content scrolling


## v0.2.0 (2014-09-29)

- jQuery API and events


## v0.1.0 (2014-09-12)

- first beta release
