Leaflet with WFS Example
========================

[TBD]

Icons: 
------

* http://thenounproject.com/noun/map-marker/#icon-No6399
* http://thenounproject.com/noun/christmas-tree/#icon-No8011






[![Bitdeli Badge](https://d2weczhvl823v0.cloudfront.net/Georepublic/leaflet-wfs/trend.png)](https://bitdeli.com/free "Bitdeli Badge")

