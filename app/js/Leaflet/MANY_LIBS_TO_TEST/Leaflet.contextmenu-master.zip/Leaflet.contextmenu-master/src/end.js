	return L.Map.ContextMenu;
	});
